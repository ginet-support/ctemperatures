float Fahr2C(float Fahr){
  /*  if (Fahr > 0) { */
    return ((5.0/9.0) * (Fahr-32)); /* what to do with negative Fahr? */   
    /*   }

    */  /*
 else {
    return (((5.0/9.0) * Fahr  -32);
    } */
}
