float C2Fahr (float Celsius);
