float Fahr2C(float Fahr);
